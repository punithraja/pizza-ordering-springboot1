package com.example.pizzaordering.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.example.pizzaordering.model.Pizza;
import com.example.pizzaordering.service.PizzaService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/pizzas")
@CrossOrigin
public class PizzaController {
    private final PizzaService service;
    public PizzaController(PizzaService service) { this.service = service; }

    @GetMapping
    public List<Pizza> list() { return service.list(); }

    @PostMapping
    public Pizza create(@Valid @RequestBody Pizza p) { return service.create(p); }

    @GetMapping("/{id}")
    public Pizza get(@PathVariable Long id) { return service.get(id); }
}
