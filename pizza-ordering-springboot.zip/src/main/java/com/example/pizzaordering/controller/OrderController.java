package com.example.pizzaordering.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import jakarta.validation.Valid;
import com.example.pizzaordering.dto.CreateOrderDTO;
import com.example.pizzaordering.model.Order;
import com.example.pizzaordering.service.OrderService;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin
public class OrderController {
    private final OrderService service;
    public OrderController(OrderService service) { this.service = service; }

    @PostMapping
    public Order place(@Valid @RequestBody CreateOrderDTO dto) {
        return service.placeOrder(dto);
    }

    @GetMapping
    public List<Order> list() { return service.listOrders(); }

    @GetMapping("/{id}")
    public Optional<Order> get(@PathVariable Long id) { return service.getOrder(id); }
}
