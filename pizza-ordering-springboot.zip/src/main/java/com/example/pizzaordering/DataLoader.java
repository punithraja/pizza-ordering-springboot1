package com.example.pizzaordering;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import com.example.pizzaordering.model.Pizza;
import com.example.pizzaordering.repo.PizzaRepo;

@Component
public class DataLoader implements CommandLineRunner {
    private final PizzaRepo repo;
    public DataLoader(PizzaRepo repo) { this.repo = repo; }

    @Override
    public void run(String... args) {
        if (repo.count() == 0) {
            repo.save(Pizza.builder().name("Margherita").price(299.0).description("Classic cheese & tomato").build());
            repo.save(Pizza.builder().name("Farmhouse").price(399.0).description("Veggies & cheese").build());
            repo.save(Pizza.builder().name("Pepperoni").price(449.0).description("Pepperoni & cheese").build());
        }
    }
}
