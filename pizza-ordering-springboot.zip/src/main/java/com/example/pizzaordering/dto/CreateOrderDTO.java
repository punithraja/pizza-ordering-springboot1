package com.example.pizzaordering.dto;

import jakarta.validation.constraints.*;
import java.util.*;

public record CreateOrderDTO(
    @NotBlank String customerName,
    @NotBlank String address,
    @NotBlank String phone,
    @NotNull List<Item> items
) {
    public static record Item(@NotNull Long pizzaId, @Positive int quantity) {}
}
