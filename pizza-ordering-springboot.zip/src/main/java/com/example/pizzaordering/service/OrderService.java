package com.example.pizzaordering.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import com.example.pizzaordering.dto.CreateOrderDTO;
import com.example.pizzaordering.model.*;
import com.example.pizzaordering.repo.*;

@Service
public class OrderService {
    private final OrderRepo orderRepo;
    private final PizzaRepo pizzaRepo;

    public OrderService(OrderRepo orderRepo, PizzaRepo pizzaRepo) {
        this.orderRepo = orderRepo;
        this.pizzaRepo = pizzaRepo;
    }

    @Transactional
    public Order placeOrder(CreateOrderDTO dto) {
        Order order = new Order();
        order.setCustomerName(dto.customerName());
        order.setAddress(dto.address());
        order.setPhone(dto.phone());

        List<OrderItem> items = new ArrayList<>();
        for (CreateOrderDTO.Item it : dto.items()) {
            Pizza pizza = pizzaRepo.findById(it.pizzaId()).orElseThrow();
            OrderItem oi = OrderItem.builder().pizza(pizza).quantity(it.quantity()).build();
            items.add(oi);
        }
        order.setItems(items);
        return orderRepo.save(order);
    }

    public List<Order> listOrders() { return orderRepo.findAll(); }
    public Optional<Order> getOrder(Long id) { return orderRepo.findById(id); }
}
