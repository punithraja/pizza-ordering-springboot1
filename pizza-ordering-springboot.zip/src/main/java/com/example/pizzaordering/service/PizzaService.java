package com.example.pizzaordering.service;

import org.springframework.stereotype.Service;
import java.util.List;
import com.example.pizzaordering.model.Pizza;
import com.example.pizzaordering.repo.PizzaRepo;

@Service
public class PizzaService {
    private final PizzaRepo repo;
    public PizzaService(PizzaRepo repo) { this.repo = repo; }

    public List<Pizza> list() { return repo.findAll(); }
    public Pizza create(Pizza p) { return repo.save(p); }
    public Pizza get(Long id) { return repo.findById(id).orElseThrow(); }
}
