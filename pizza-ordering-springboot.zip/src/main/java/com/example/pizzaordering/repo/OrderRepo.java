package com.example.pizzaordering.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.pizzaordering.model.Order;

public interface OrderRepo extends JpaRepository<Order, Long> {
}