package com.example.pizzaordering.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.pizzaordering.model.Pizza;

public interface PizzaRepo extends JpaRepository<Pizza, Long> {
}