# Pizza Ordering API (Spring Boot)

This is a Spring Boot rewrite/skeleton for a Pizza Ordering service.

## Endpoints
- `GET /api/pizzas` — list menu
- `POST /api/pizzas` — create a pizza (body: name, price, description)
- `GET /api/pizzas/{id}` — fetch one
- `POST /api/orders` — place order (CreateOrderDTO with items)
- `GET /api/orders` — list orders
- `GET /api/orders/{id}` — get one

## Run locally
```bash
./mvnw spring-boot:run
```

## Build jar
```bash
./mvnw -q -DskipTests package
java -jar target/pizzaordering-0.0.1-SNAPSHOT.jar
```

## Docker
```bash
docker build -t pizza-api .
docker run -p 8080:8080 pizza-api
```

H2 console: `/h2-console` (JDBC URL: `jdbc:h2:mem:pizza`).
